module.exports = {
    name: 'vaultip',
    description: 'Vault Hunters IP',
    execute(message, args){
        message.channel.send('vault.aquaticraft.eu');

    }
}