module.exports = {
    name: 'testembed',
    description: 'listing of servers currently active',    
    execute(message, args, discord){
        const exampleEmbed = new Discord.MessageEmbed()
	.setColor('#0099ff')
	.setTitle('listing of servers currently active')
	.setURL('https://www.twitch.tv/3dd1n')
	.setAuthor('Aquaticraft Team', 'https://cdn.discordapp.com/attachments/719853886323687476/856609462629433344/fb703f5c30647e328edf5ee9772b8ca1.png')
	.setDescription('listings of servers Active')
	.setThumbnail('https://i.imgur.com/wSTFkRM.png')
	.addFields(
		{name: 'Vault Hunters Ip', value: 'Public'},
        {name: 'Vanilla Minecraft', value: 'Invite only'},
        {name: 'Aquatech', value: 'Applications'},
        {name: 'Enigmatica 6', value: 'Patreon Only'},
	)
	.setImage('https://cdn.discordapp.com/attachments/719853886323687476/856609462629433344/fb703f5c30647e328edf5ee9772b8ca1.png')
	.setTimestamp()
	.setFooter('Make sure to Read All rules and it applies everywhere');

    message.channel.send(newEmbed);
    
    }
}