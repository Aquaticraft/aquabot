module.exports = {
    name: 'serverlist',
    description: 'listing of servers currently active',
    execute(message, args){
        message.channel.send('Vaulthunters = Public, Enigmatica 6 = Patreon only, Vanilla Minecraft = Invite only, Tech Minecraft = Applications <#856484604026159106>');

    }
}