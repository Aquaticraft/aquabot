const { DiscordAPIError } = require("discord.js");

module.exports = {
    name: 'serverlist',
    description: 'listing of servers currently active',    
    execute(message, args, Discord){
    const newEmbed = new Discord.messageEmbed()
    .setcolor ('#ccff00')
    .setTitle ('ServerList')
    .setURL('https://www.twitch.tv/3dd1n')
    .setdescription('this is a server list for aquaticraft')
    .addfields(
        {name: 'Vault Hunters Ip', value: 'Public'},
        {name: 'Vanilla Minecraft', value: 'Invite only'},
        {name: 'Aquatech', value: 'Applications'},
        {name: 'Enigmatica 6', value: 'Patreon Only'},
    )
    .addImage('https://cdn.discordapp.com/avatars/842658116709515264/fb703f5c30647e328edf5ee9772b8ca1.webp?size=1024')

    }
}