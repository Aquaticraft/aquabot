module.exports = {
    name: 'techmc',
    description: 'techmc applications',
    execute(message, args){
        message.channel.send('<#856484604026159106>');

    }
}