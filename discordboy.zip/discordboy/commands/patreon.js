module.exports = {
    name: 'patreon',
    description: 'patreon to support us',
    execute(message, args){
        message.channel.send('https://www.patreon.com/aquaticraftservers');
    }
}