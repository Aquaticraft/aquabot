module.exports = {
    name: 'interview',
    description: 'interview questions',
    execute(message, args){
        message.channel.send('Hello! What is your experience with moderating on discord or minecraft servers! How did you find aquaticraft and why do you want to be a helper!  What is ur Age What country do you come from and what timezone do u have (if you dont feel comfortable with any of the questions that is fine) Do you work best alone or on a team? What could you bring to make us more successful? What skills and strengths can you bring to this position?  Do you have any questions for me?');
    }
}