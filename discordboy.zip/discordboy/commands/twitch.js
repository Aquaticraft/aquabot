module.exports = {
    name: 'twitch',
    description: 'twitch links for staff team',
    execute(message, args){
        message.channel.send('https://www.twitch.tv/3dd1n , https://www.twitch.tv/wal_e_ , https://www.twitch.tv/mgfirestar36 , https://www.twitch.tv/hedgehog_hero_');
    }
}