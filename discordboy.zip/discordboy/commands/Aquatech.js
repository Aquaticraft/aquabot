module.exports = {
    name: 'aquatech',
    description: 'aquatech applications',
    execute(message, args){
        message.channel.send('<#856484604026159106>');

    }
}
